package application;
	
import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.chart.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.Group;

public class Main extends Application 
{	
	Connection connection;
	static Map<String,Double> percentUsersSubregion1 = new HashMap <String,Double>();
	static Map<String,List<String>> SubregionCountry = new HashMap<String,List<String>>();
	public static void main(String[] args) 
	{
		
		Main program = new Main();
		if (program.connect())
		{	
			Map<String,Integer> subregionMap = getAllSubregion();//подготовка данных для 1го задания
			percentUsersSubregion1 = GetPercentUsersSubregion(subregionMap);//подготовка данных для 1го задания
			SmallestNumberOfRegisteredInWesternEurope();// 2е задание
			percentageOfInternetUsersInCountries();// 3е задание
			launch(args);// вызов таблицы
		}
	}
	
	boolean connect()
	{
		try 
		{
			Class.forName("org.sqlite.JDBC");
			Connection connection = DriverManager.getConnection(
			"jdbc:sqlite:D:\\SQL Lite\\CountryJava.db");
			System.out.println("Connected");
			return true;
		}
		catch (Exception e)
		{
			System.out.println (e.getMessage());
			return false;
		}
	}

	
    public static Map<String,Integer> getAllSubregion() /// 1 часть решения 1 задачи.
    {
        try
        {
        	Connection connection = DriverManager.getConnection("jdbc:sqlite:D:\\SQL Lite\\CountryJava.db");// подключение к бд
        	Statement statement = connection.createStatement();
        	
            ResultSet resultSet = statement.executeQuery("SELECT Subregion FROM [location country]");// создание запроса на получение всех субрегионов
            
            Map<String,Integer> dictionarySubregions = new HashMap<String,Integer>(); // будет ниже реальзован подсчет стран входящий в субрегионы
            ArrayList<String> places = new ArrayList<String>();// в листе будет запись всех данных из запроса
            
            while (resultSet.next()) 
            {
            	String subregion = resultSet.getString("Subregion");// преобразование данных столбика Subregion в стринг 
            	places.add(subregion);// добавление в лист 
            }
			
			Map<String, Integer> frequency = places.stream().collect(Collectors.toMap( e -> e, e -> 1, Integer::sum));// подсчет всех стран 
			frequency.forEach((k, v) -> dictionarySubregions.put(k, v)); ///System.out.println(dictionarySubregions);// запись субрег. и кол-ва в нем стран
			return dictionarySubregions;
        }
        
        catch (Exception e) // если будет ошибка в запросе или подключении то выведет что не так.
        {
            System.out.println(e.getMessage());
            return null;
        }
    }
    
    
    public static Map<String,Double> GetPercentUsersSubregion( Map<String, Integer> subregionMap) // 2 часть решения 1 задачи
	{
		Map<String,Double> percentUsersSubregion = new HashMap <String,Double>();// словарь в котором будет название субрегиона и его процент
        try
        {
			Connection connection = DriverManager.getConnection("jdbc:sqlite:D:\\SQL Lite\\CountryJava.db");// подключение к БД, оно всегда будет одно и то же
			Statement statement = connection.createStatement();
			
			
			for (int i = 0; i < subregionMap.keySet().size(); i++)// Тут пробигаюсь по всем субрегионам для их запросов и записи
			{
				List<String> countryList = new ArrayList<String>();// создание листа по новой с нов.циклом для записи стран в свои субрегионы
				ResultSet resultSet = statement.executeQuery("SELECT \"Country or area\" "
						+ "FROM [location country]"
						+ "WHERE Subregion = " + '"' + subregionMap.keySet().toArray()[i].toString() + '"');// тут я беру страны из табл по условию Субрегион = (субрег пол из 1 шаг 1 задания)
				
	            while (resultSet.next()) 
	            {
	            	String country = resultSet.getString("Country or area"); // получаю название стран
	            	countryList.add(country);// записываю в лист, который по началу следующего цикла очиститься для записи других стран субрегионов, выше
	            }
	            SubregionCountry.put(subregionMap.keySet().toArray()[i].toString() , countryList);// записываю ключ субрегион - значение лист субрегионов 
			}
			
			
			// после заполнения словаря субрегион - лист стран начинаю подсчитывать кол-во населения и пользователей сети
			for (int i = 0; i < subregionMap.keySet().size(); i++)// пробегаюсь по всем субрегионам
			{
				ResultSet resultSet = statement.executeQuery("SELECT \"Internet users\" , Population FROM [people country] "
						+ "WHERE Population IS NOT NULL and Population <> '' AND \"Country or area\" IN " 
						+ SubregionCountry.get(SubregionCountry.keySet().toArray()[i])
						.toString().replace("[","(\"").replace("]","\")").replace(", ","\", \"") );
				// запрос имеет вид - выбрать полльзователей интернета + популяцию страны ГДЕ популяция не пустая(в таблице было 3-4 пустых значения) 
				// и где страны состоят в списке (далее список старн по субрегиону). 
				//Для придания формы нужного для запроса я использовал ком реплейс удаляя и заменяя кавычки и запятые на круглые ковычки и разбиение значени по ""
				//То есть для запроса нужна была форма ("страна", "страна","страна", ...)
				
				var user = 0;// счетчик пользователей интернета
				var popul = 0;// счетчик населения
	            while (resultSet.next()) 
	            {
	            	var Internet_users = Integer.parseInt(resultSet.getString("Internet users").replace(",", ""));// запись населения и пользователей интернета по столбцам
	            	var Population = Integer.parseInt(resultSet.getString("Population").replace(",", ""));// и так же идет удаление запятых, то есть из формы 111,111,111 в 111111111
	            	user += Internet_users;//подсчет всего кол-ва
	            	popul += Population;//подсчет всего кол-ва
	            	
	            }
	            percentUsersSubregion.put(SubregionCountry.keySet().toArray()[i].toString(),
	            		Double.parseDouble(String.format("%.3g%n" ,//вместо 3ки можно поставить сколько нужно знаков 
	            				(double) user * 100.0 / (double) popul)// формула для подсчета процента населения и юзеров
	            					.replace(",",".")));// замена , на . для того что бы перевести стринт в дабл.
			}
			return percentUsersSubregion;	
        }
        
		catch (Exception e) // если какая то ошибка опять же то будет отсылать что не так или запрос или данные не в том формате.
        {
            System.out.println(e.getMessage());
            return null;
        }
		
	}
	
    static Void SmallestNumberOfRegisteredInWesternEurope()// 2е задание
    {
        try
        {	
	    	Connection connection = DriverManager.getConnection("jdbc:sqlite:D:\\SQL Lite\\CountryJava.db");// подключение к БД
			Statement statement = connection.createStatement();
	    	
	    	ResultSet resultSet = statement.executeQuery("SELECT \"Country or area\" , \"Internet users\" FROM [people country] "
					+ "WHERE Population IS NOT NULL and Population <> '' AND \"Country or area\" IN " 
					+ SubregionCountry.get("Western Europe")
					.toString().replace("[","(\"").replace("]","\")").replace(", ","\", \"")// так же как и в первом задании приведение к формату запроса
					+ "ORDER BY \"Internet users\" DESC ");// попытка сортировать не удалась таким способом, возвращает то же что и без него
	    	//Запрос звучит так - выбрать страну, пользователей ГДЕ популяция не нулл и страны входят в (лист старн со значением Восточной европы)
	    	
	    	Map<String,Integer> directionContryUser = new HashMap <String,Integer>();// словарь с ключем Страна и зачением пользователь интернета
	    	
            while (resultSet.next()) 
            	directionContryUser.put(resultSet.getString("Country or area"),//вставляем значение стоки страна в словарь 
            			Integer.parseInt(resultSet.getString("Internet users").replace(",", "")));// значение строки пользователи интернета
            //так же убирая , в числах
            
            List<Integer> listInt = new ArrayList<Integer>();// лист всех пользователей, нужен для сортировки
            for (int i = 0; i < directionContryUser.keySet().size(); i++)// запись, с ней все понятно, в лист добавляются все значения 
        	    listInt.add(directionContryUser.get(directionContryUser.keySet().toArray()[i]));// которые есть в словаре
            
           	Collections.sort(listInt);//дальше просто сортировка от меньшего к большему
           	
            System.out.println("2) The country with the smallest number of registered Internet users in Western Europe.");
           	// дальше просто сверерка наименьшего значение из листа со значением ключа из словаря(что бы название страны получить)
       		for (int j = 0; j < directionContryUser.keySet().size(); j++)
       		{
       			if (directionContryUser.get(directionContryUser.keySet().toArray()[j]) == listInt.toArray()[0])
       					System.out.println( "  " + directionContryUser.keySet().toArray()[j] 
       										+ " " + listInt.toArray()[0]);// 0 позиция так как лист сортирован от меньшего к большему
       		}

	       	System.out.println("All list country in Western Europe");// весь список стран 
           	System.out.println(directionContryUser);
           	System.out.println("-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --"
           			+ " -- -- -- -- -- -- -- -- -- --");
	    	return null;
        }
        
		catch (Exception e) // сообщение о ошибке(запрос / не тот тип данных)
        {
            System.out.println(e.getMessage());
            return null;
        }
        
    }
    
    static Void percentageOfInternetUsersInCountries()
    {
        try
        {	
	    	Connection connection = DriverManager.getConnection("jdbc:sqlite:D:\\SQL Lite\\CountryJava.db");// подключение к бд
			Statement statement = connection.createStatement();
	    	
	    	ResultSet resultSet = statement.executeQuery("SELECT \"Country or area\" , \"Internet users\", Population FROM [people country] "
					+ "WHERE Population IS NOT NULL and Population <> '' ");
	    	// запрос выглядит так - Выбрать страну, пользователей, популяцию  ГДЕ популяция без нулл
	    	
	    	
            List<Double> listDouble = new ArrayList<Double>();// лист для процентов
            Map<String, Double> dictionaryPercent = new HashMap<String,Double>();// словарь с ключем Страна - значение процент
           	
	    	while (resultSet.next())
	    	{
	    		String country = resultSet.getString("Country or area");//запись из колонки страна
	    		Integer users = Integer.parseInt(resultSet.getString("Internet users").replace(",", ""));//запись из колонки пользователей
	    		Integer population = Integer.parseInt(resultSet.getString("Population").replace(",", ""));// запись из колонки популяция
	    		Double percent = Double.parseDouble(String.format("%.3g%n" , (double) users * 100.0 / (double) population).replace(",","."));// итоговый процент пользователей 
	    		if(percent >= 75.0 && percent <= 85.0)// условие задачи
	    		{
	    			listDouble.add(percent);// добавление в лист , для сортировки
		    		dictionaryPercent.put(country, percent);// добавление в словарь значений
	    		}
	    	}
           	Collections.sort(listDouble);// сортировка, для того что бы было значение с большое на малое нужно перевернуть лист
           	
            System.out.println("3) The percentage of registered Internet users of which is in the range from 75% to 85% (the first three)"); // я брал от малого к большому
           	
           	for (int i = 0; i < 3; i++)// взял 3 первых, можно поменять значение, например на размер ключей и выведет весь список
           	{
           		for (int j = 0; j < dictionaryPercent.keySet().size(); j++)// сверка листа и значений в ключе словаря для вывода
           		{
           			int number = i + 1;
           			if (dictionaryPercent.get(dictionaryPercent.keySet().toArray()[j]) == listDouble.toArray()[i])
           					System.out.println("    " + number + ") " 
           							+ dictionaryPercent.keySet().toArray()[j] 
           										+ " " + listDouble.toArray()[i] + "%");
           		}
           	}
           	
           	System.out.println("All list");
           	System.out.println(dictionaryPercent);
           	System.out.println("-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --"
           			+ " -- -- -- -- -- -- -- -- -- --");
           	
	    	return null;
        }
		catch (Exception e) // ловит ошибки с типом и запросом
        {
            System.out.println(e.getMessage());
            return null;
        }
    }
    
	@Override public void start(Stage stage) // не углублялся как он работает, взято из JavaJx 
	{
	        Scene scene = new Scene(new Group());
	        stage.setTitle("График процентного соотношения.");// название 
	        stage.setWidth(900);// размер в длину
	        stage.setHeight(800);// в ширину
	        
	        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();// коллекция данных которые в будующем войдут в график
	        
	        for (int i = 0; i < percentUsersSubregion1.keySet().size(); i++)// пробегаюсь по всем субрегионам
	        {
	        	pieChartData.add(new PieChart.Data(percentUsersSubregion1.keySet().toArray()[i].toString(),// записываюназвание субрегиона
	        			percentUsersSubregion1.get(percentUsersSubregion1.keySet().toArray()[i].toString())));//  значение субрегиона 
	        }
	        final PieChart chart = new PieChart(pieChartData);// тут объявление графика
	        chart.setMinWidth(750);// размеры графика в ширину
	        chart.setMinHeight(750);// в высоту
	        chart.setLabelLineLength(6);// на сколько далеко будут названия от графика
	        chart.setTitle("График процентного соотношения.");
	        
	        
			for (final PieChart.Data data : chart.getData()) // ивент которые будет выводить данные субрегиона по которому нажмете 
			{
			    data.getNode().addEventHandler(MouseEvent.MOUSE_PRESSED,// добавление ивента
			        new EventHandler<MouseEvent>() {
			            @Override public void handle(MouseEvent e) {
			            	System.out.println("----------------------------------------------------");
			            	System.out.println(String.valueOf("In the subregion " + data.getName() 
			            	+ " " + data.getPieValue()) + "% the population uses the Internet");// будет выводить - В субрегионе "название" "процент" % от пользователей интернета 
			            	
			             }
			        }
			    );
			}

	        ((Group) scene.getRoot()).getChildren().add(chart);//добавление значений
	        stage.setScene(scene);// окно?
	        stage.show();   // показ
    }
}



